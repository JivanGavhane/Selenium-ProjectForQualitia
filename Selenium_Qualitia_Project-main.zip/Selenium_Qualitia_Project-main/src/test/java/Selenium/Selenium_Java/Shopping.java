package Selenium.Selenium_Java;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Shopping {

	@Test(dataProvider="Data_provide")
	public void Shop(String Vegitable) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(5));

		driver.get("https://rahulshettyacademy.com/seleniumPractise/");
		driver.manage().window().maximize();

		//Thread.sleep(3000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("h4.product-name")));

		int j = 0;

		List<WebElement> products = driver.findElements(By.cssSelector("h4.product-name"));

		for (int i = 0; i < products.size(); i++)

		{

			String[] name = products.get(i).getText().split("-");

			String formattedName = name[0].trim();

			if (Vegitable.contains(formattedName))

			{

				j++;

				driver.findElements(By.xpath("//div[@class='product-action']/button")).get(i).click();

			}

		}

		driver.findElement(By.xpath("//a[@class='cart-icon']")).click();
		driver.findElement(By.xpath("//button[text()='PROCEED TO CHECKOUT']")).click();

		//Thread.sleep(3000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".promoCode")));

		driver.findElement(By.cssSelector(".promoCode")).sendKeys("rahulshettyacademy");
		driver.findElement(By.cssSelector(".promoBtn")).click();

		//Thread.sleep(5000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='promoInfo']")));
		String Code = driver.findElement(By.xpath("//span[@class='promoInfo']")).getText().trim();

		String CodeCheck = "Code applied ..!";
		if (Code.equalsIgnoreCase("CodeCheck")) {
			Assert.assertTrue(true);
		} else {
			Assert.assertFalse(false);
		}

		driver.findElement(By.xpath("//button[text()='Place Order']")).click();

		WebElement country = driver.findElement(By.xpath("//div[@class='products']//select"));

		Select select = new Select(country);

		select.selectByVisibleText("India");

		driver.findElement(By.cssSelector(".chkAgree")).click();

		driver.findElement(By.xpath("//button[text()='Proceed']")).click();

	}

	@DataProvider
	public Object[] Data_provide() {

		Object[] obj = new Object[10];

		obj[0] = "Cucumber";
		obj[1] = "Brocolli";
		obj[2] = "Beetroot";
		obj[3] = "BeeCauliflower";
		obj[4] = "Carrot";
		obj[5] = "Tomato";
		obj[6] = "Beans";
		obj[7] = "Brinjal";
		obj[8] = "Capsicum";
		obj[9] = "Mushroom";
	
		return obj;
	}
}
