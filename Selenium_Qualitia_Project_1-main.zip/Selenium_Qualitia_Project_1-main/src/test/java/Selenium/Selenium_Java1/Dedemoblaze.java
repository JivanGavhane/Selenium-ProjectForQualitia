package Selenium.Selenium_Java1;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Dedemoblaze {

	@Test(dataProvider="Data_provide")
	public void SearchAndAddProduct(String Product) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.demoblaze.com/index.html");

		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(5));
		driver.manage().window().maximize();

		driver.findElement(By.id("login2")).click();

		//Thread.sleep(3000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("loginusername")));

		driver.findElement(By.id("loginusername")).sendKeys("JivanGavhane");

		driver.findElement(By.id("loginpassword")).sendKeys("Jivanbro@7889");

		driver.findElement(By.xpath("//button[@onclick='logIn()']")).click();

		//Thread.sleep(3000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("nameofuser")));
		String OriginalUsername = "JivanGavhane";
		String UserName = driver.findElement(By.id("nameofuser")).getText().split("Welcome")[1].trim();

		// 1.Verifying Login Status and Correct user at a time
		if (UserName.equals(OriginalUsername)) {
			Assert.assertTrue(true);
		} else {
			Assert.assertFalse(false);
		}

		driver.findElement(By.xpath("//a[@onclick=\"byCat('notebook')\"]")).click();

		//		Thread.sleep(5000);
		//		List<WebElement> ItemList = driver.findElements(By.xpath("//div[@id='tbodyid']//h4/a"));

		while(true) {

			try {
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='tbodyid']//h4/a[contains(.,'"+Product+"')]"))).click();
				break;
			}catch (Exception e) {
				try {
					driver.findElement(By.xpath("//button[contains(.,'Next')]")).click();
				}catch (Exception ex) {
					// TODO: handle exception
					System.out.println("\nNo new page, this is the last page.\n");
					break;
				}
			}
		}

		//		for (int i = 0; i < ItemList.size(); i++) {
		//			String ProductName = ItemList.get(i).getText().trim();
		//			if (Product.equals(ProductName)) {
		//				driver.findElements(By.xpath("//div[@id='tbodyid']//h4/a")).get(i).click();
		//				break;
		//			}
		//		}

		//Thread.sleep(5000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Add to cart']")));
		driver.findElement(By.xpath("//a[text()='Add to cart']")).click();

		//		Thread.sleep(3000);
		String AddMessage=wait.until(ExpectedConditions.alertIsPresent()).getText().trim();
		//		String AddMessage = driver.switchTo().alert().getText().trim();
		String ExpectedMessage = "Product added.";
		if (ExpectedMessage.equals(AddMessage)) {
			Assert.assertTrue(true);
		} else {
			Assert.assertFalse(false);
		}

		driver.switchTo().alert().accept();

		driver.findElement(By.cssSelector("#cartur")).click();

		Thread.sleep(3000);

		//		wait.until(ExpectedConditions.numberOfElementsToBe(By.xpath("//tbody[@id='tbodyid']//td[2]"), 6));

		List<WebElement> addedproduct=wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//tbody[@id='tbodyid']//td[2]")));
		//		List<WebElement> addedproduct = driver.findElements(By.xpath("//tbody[@id='tbodyid']//td[2]"));


		for (int i = 0; i < addedproduct.size(); i++) {
			String ProductName1 = addedproduct.get(i).getText().trim();
			if (Product.equals(ProductName1)) {
				Assert.assertTrue(true);
				break;
			}
			else {
				Assert.assertFalse(false);
			}
		}

		//Thread.sleep(3000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#logout2")));
		driver.findElement(By.cssSelector("#logout2")).click();


	}

	@DataProvider
	public Object[] Data_provide() {

		List<String> ProductsList = new ArrayList<String>(
				Arrays.asList(
						"MacBokok air",
						"Sony vaio i5",
						"Sony vaio i7",
						"Dell i7 8gb",
						"2017 Dell 15.6 Inch",
						"MacBook Pro"
						)
				);		

		return ProductsList.toArray();
	}
}
