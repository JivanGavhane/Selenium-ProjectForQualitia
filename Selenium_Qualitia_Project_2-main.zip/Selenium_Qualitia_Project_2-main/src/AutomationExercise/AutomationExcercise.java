package AutomationExercise;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class AutomationExcercise {
	
	@Test(dataProvider="Data_provide")
	public void AutomationExercise(String UserName,String Email,String Password,String day,String Month,String Year,String Fname,String Lname,String Companey,String add1,String add2,String Country,String State,String City,String PinCode,String Mobile) throws InterruptedException
	{
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;

		driver.get("https://www.automationexercise.com/test_cases");
		
		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(5));
		
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("Signup / Login")));
		
		//Thread.sleep(5000);
		driver.findElement(By.linkText("Signup / Login")).click();
		
		driver.findElement(By.xpath("//input[@data-qa='signup-name']")).sendKeys(UserName);
		
		driver.findElement(By.xpath("//input[@data-qa='signup-email']")).sendKeys(Email);
		
		driver.findElement(By.xpath("//button[text()='Signup']")).click();
		
		//Thread.sleep(5000);
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("//input[@value='Mr']")));
		
		driver.findElement(By.xpath("//input[@value='Mr']")).click();
		
		driver.findElement(By.cssSelector("#password")).sendKeys(Password);
		
		WebElement days = driver.findElement(By.cssSelector("#days"));
		Select se = new Select(days);
		se.selectByVisibleText(day);
		
		WebElement months = driver.findElement(By.cssSelector("#months"));
		Select se1 = new Select(months);
		se1.selectByVisibleText(Month);
		
		WebElement year = driver.findElement(By.cssSelector("#years"));
		Select se2 = new Select(year);
		se2.selectByVisibleText(Year);
		
		
		//driver.findElement(By.cssSelector("#newsletter")).click();
//		driver.findElement(By.xpath("//label[contains(.,'Sign up for our newsletter!')]")).click();		
//		driver.findElement(By.xpath("//label[contains(.,'Receive special offers from our partners!')]")).click();

        jsExecutor.executeScript("arguments[0].scrollIntoView(true);", driver.findElement(By.xpath("//label[contains(.,'Sign up for our newsletter!')]")));

        jsExecutor.executeScript("arguments[0].click();", driver.findElement(By.xpath("//label[contains(.,'Sign up for our newsletter!')]")));
        jsExecutor.executeScript("arguments[0].click();", driver.findElement(By.xpath("//label[contains(.,'Receive special offers from our partners!')]")));

		
		
		driver.findElement(By.id("first_name")).sendKeys(Fname);
		driver.findElement(By.id("last_name")).sendKeys(Lname);
		
		driver.findElement(By.id("company")).sendKeys(Companey);
		
		driver.findElement(By.id("address1")).sendKeys(add1);
		driver.findElement(By.id("address2")).sendKeys(add2);
		
		WebElement country = driver.findElement(By.id("country"));
		Select se3 = new Select(country);
		
		se3.selectByVisibleText(Country);
		
		driver.findElement(By.id("state")).sendKeys(State);
		
		driver.findElement(By.id("city")).sendKeys(City);
		
		driver.findElement(By.id("zipcode")).sendKeys(PinCode);
		
		driver.findElement(By.id("mobile_number")).sendKeys(Mobile);
		
//		Thread.sleep(2000);
//		driver.findElement(By.xpath("//button[@data-qa=\"create-account\"]")).click();
		
		// Use JavascriptExecutor to click the element
        jsExecutor.executeScript("arguments[0].scrollIntoView(true);", driver.findElement(By.xpath("//button[@data-qa=\"create-account\"]")));

        jsExecutor.executeScript("arguments[0].click();", driver.findElement(By.xpath("//button[@data-qa=\"create-account\"]")));
		
		//Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Continue")));
		driver.findElement(By.linkText("Continue")).click();
		
		//Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Delete Account")));
		driver.findElement(By.linkText("Delete Account")).click();
		
		//Thread.sleep(3000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Continue")));
		driver.findElement(By.linkText("Continue")).click();

	}
	
	@DataProvider
	public Object[][] Data_provide()
	{
		//Provide 3 set of Data
		//Good CBIL Username and password
		//bad CBIL Username and password
		//Average CBIl Username and Password.
		
		Object [][] obj = new Object[1][16];
		//3 iteration and 2 filed in each iteration
		
		obj[0][0] = "JivanGavhane";
		obj[0][1] = "Jivan.Gavhane@qualitia.ai";
		obj[0][2] = "Jivanbro@1234";
		obj[0][3] = "3";
		obj[0][4] = "September";
		obj[0][5] = "1998";
		obj[0][6] = "Jivan";
		obj[0][7] = "Gavhane";
		obj[0][8] = "Zensoft";
		obj[0][9] = "Plot No 14, Bhure mala";
		obj[0][10] = "Shivaji Nagar";
		obj[0][11] = "India";
		obj[0][12] = "Maharashtra";
		obj[0][13] = "Jalgaon";
		obj[0][14] = "425001";
		obj[0][15] = "9689274879";
		
		return obj;
	}

}
