var values= [10,20,30,40,50];

//sum of number 
let sumofnum = values.reduce((sum,num)=>sum+num,0);
console.log(sumofnum);

//create new array and put only even number
let new_filter_even = values.filter(value=>value%2==0);
console.log(new_filter_even);

//multiplay each element with 3
let mul_values = values.map(values=>values*3);
console.log(mul_values);

//add all mul values(sum of number)
let sumofnewnum = mul_values.reduce((value,num)=>value+num,0);
console.log(sumofnewnum);

